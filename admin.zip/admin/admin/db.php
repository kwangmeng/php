<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "kwangmeng";
$dbtable = "industrial";
// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbtable);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>