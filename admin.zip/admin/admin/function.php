<?php
include 'session.php';
    include 'dbfunc.php';

function login($email, $password){

         if($email != "" || $password != ""){
          $login = DBlogin($email, $password);
            if($login == 1){
         $_SESSION['email'] = $email;
        $string = '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Authenticated! Redirecting..</div><script>window.location.href="index.php";</script>';
            return $string;
            }else if($login == 2){
            $string = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            Error, Invalid Credentials!
                            </div>';
                                    return $string;
            }


      }else{
       $string = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                               Error, Invalid Credentials!
                            </div>';
                                    return $string;
      }
}


function getUsers(){

    $users  = getDBUsers();
    return $users;
}

function getUserCount(){

    $users  = count(getDBUsers());
    return $users;
}

function getProjects(){
    $projects = getDBProject();
    return $projects;
}

function getProjCount(){

    $users  = getDBProjCount();
    return $users;
}

function getMoneyCount(){

    $users  = getDBMoneycount();
    return $users;
}

function getEmailCount(){

    $users  = getDBEmailCount();
    return $users;
}

?>