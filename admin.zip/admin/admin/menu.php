  <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="users.php">
                            <i class="fa fa-users fa-fw"></i> Users</a>
             
                          
                        </li>
                     
                        <li>
                            <a href="projects.php"><i class="fa fa-table fa-fw"></i> Projects</a>
                        </li>
                        <li>
                            <a href="payment.php"><i class="fa fa-money fa-fw"></i> Payments</a>
                        </li>
                        <li>
                            <a href="emails.php"><i class="fa fa-envelope fa-fw"></i> Emails Enquiry</a>
                        
                        </li>
                        <li>
                            <a href="blogs.php"><i class="fa fa-sitemap fa-fw"></i>News/Blogs</a>
                         
                                 
                        </li>
                           <li>
                            <a href="banners.php"><i class="fa fa-image fa-fw"></i>Index Banners</a>
                        </li>
            
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->