<?php 


function DBlogin($email, $password){
    include 'db.php';
  $email = mysqli_real_escape_string($conn, $email);
  $sql = "SELECT password, role FROM users where email='$email'";
  $result = mysqli_query($conn,$sql);
  $rows = mysqli_fetch_assoc($result);
  if(password_verify($password, $rows['password']) && $rows['role'] == "admin" ){
    return 1;
  }else{
    return 2;
  }
}


function getDBUsers(){
    include 'db.php';
    $sql = "SELECT * FROM users";
    $result = mysqli_query($conn,$sql);
    $resultArray = array();
  while($row = mysqli_fetch_assoc($result)) {
  $resultArray[] = $row;
  }
  return $resultArray;
}

function getDBProject(){
    include 'db.php';
    $sql = "SELECT * FROM projects";
    $result = mysqli_query($conn,$sql);
    $resultArray = array();
  while($row = mysqli_fetch_assoc($result)) {
  $resultArray[] = $row;
  }
  return $resultArray;
}

function getDBProjCount(){
    include 'db.php';
    $sql = "SELECT * FROM projects";
    $result = mysqli_query($conn,$sql);
    $resultArray = array();
  while($row = mysqli_fetch_assoc($result)) {
  $resultArray[] = $row;
  }
  return count($resultArray);
}

function getDBEmailCount(){
    include 'db.php';
    $sql = "SELECT * FROM emails";
    $result = mysqli_query($conn,$sql);
    $resultArray = array();
  while($row = mysqli_fetch_assoc($result)) {
  $resultArray[] = $row;
  }
  return count($resultArray);
}

function getDBMoneyCount(){
    include 'db.php';
    $sql = "SELECT * FROM projects";
    $result = mysqli_query($conn,$sql);
    $resultArray = array();
  while($row = mysqli_fetch_assoc($result)) {
  $resultArray[] = $row;
  }
  return $resultArray;
}




?>